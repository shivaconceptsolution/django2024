from django.urls import path
from . import views
urlpatterns=[
    path('',views.index,name='index'),
    path('radioexample',views.radioexample,name='radioexample'),
    path('checkboxexample',views.checkboxexample,name='checkboxexample'),
    path('listboxexample',views.listboxexample,name='listboxexample'),
    path('dropdownexample',views.dropdownexample,name='dropdownexample')
]