from django.shortcuts import render

def index(request):
    if request.method=='POST':
        a=request.POST['num1']
        b=request.POST['num2']
        match request.POST.get('btnsubmit'):
          case '+':
           c=int(a)+int(b)
          case '-':
           c=int(a)-int(b)
          case '*':
            c=int(a)*int(b)
          case '/':
            c=int(a)/int(b)
        '''if request.POST.get('btnsubmit')=='+':
            c=int(a)+int(b)
        elif request.POST.get('btnsubmit')=='-':
            c=int(a)-int(b)
        elif request.POST.get('btnsubmit')=='*':
            c=int(a)*int(b)
        elif request.POST.get('btnsubmit')=='/':
            c=int(a)/int(b)'''
        return render(request,"operation/index.html",{"num1":a,"num2":b,"result":c})

    else:
      return render(request,"operation/index.html")
