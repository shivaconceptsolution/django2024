from django.shortcuts import render
from django.http import HttpResponse
def index(request):
    return HttpResponse('Hello World')
def addition(request):
    if request.method=='POST':
        a,b = int(request.POST['txtnum1']),int(request.POST['txtnum2'])
        c=a+b
        return render(request,'helloapp/addition.html',{'key':c})
    else:
        return render(request,'helloapp/addition.html')
